import "./styles.css";
import { useState } from "react";

export default function App() {
  let corUserName = "eswar";
  let corPassword = "guptha";
  let [count, setCount] = useState(0);
  let [userName, setUserName] = useState("");
  let [password, setPassword] = useState("");
  let [display, setDisplay] = useState(false);

  let usernameHandler = (e) => {
    setUserName(e.target.value);
    setDisplay(false);
  };

  let passwordHandler = (e) => {
    setPassword(e.target.value);
    setDisplay(false);
  };

  let submitHandler = (e) => {
    e.preventDefault();
    setDisplay(true);
    setCount(count + 1);
    console.log(display, count);
  };

  return (
    <div className="App">
      <h1>Event information</h1>
      <form onSubmit={submitHandler}>
        <label>
          Username :{" "}
          <input type="text" value={userName} onChange={usernameHandler} />
        </label>
        <br />
        <label>
          password :{" "}
          <input type="password" value={password} onChange={passwordHandler} />
        </label>

        <br />
        <button type="submit">Submit</button>
      </form>
      <div>
        {
          <>
            {display ? (
              <div>
                <h2>
                  {corUserName == userName && corPassword == password
                    ? "You won"
                    : "Wrong details"}
                </h2>
              </div>
            ) : (
              ""
            )}
          </>
        }
      </div>
    </div>
  );
}
